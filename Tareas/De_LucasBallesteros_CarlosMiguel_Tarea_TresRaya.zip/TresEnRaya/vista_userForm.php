<?php ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Juego de las tres en raya</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<div id="content">

    <div class="admin new">
        <h1>Introducir nombre de usuario</h1>

        <form action="" method="post">
            <label for="username">Introudzca su nombre de usuario</label>
            <input id="username" name="username" type="text" required maxlength="22">
            <br>
            <input type="submit" value="Envíar">

        </form>

    </div>

</div>
</body>
</html>