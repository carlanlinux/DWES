<?php
define("DB_SERVER", "localhost");
define("DB_NAME", "tres_raya");
define("DB_USER", "root");
define("DB_PASS", "root");
