<?
include 'wsdl2php.php';
?>